package Tut7;

import java.util.Scanner;

public class act3 {
    public static String changeToBinaryForm(int n){
        if (n == 0){
            return "0";
        }
        else if (n < 0){
            return "-1";
        }
        else{
            return changeToBinaryForm(n/2) + n % 2 ;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter an integer: ");
        int n = sc.nextInt();
        System.out.println("The binary form: " + changeToBinaryForm(n));
    }
}
