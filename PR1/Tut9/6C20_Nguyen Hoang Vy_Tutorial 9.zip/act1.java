package Tut9;


import java.io.*;
import java.util.Scanner;

import static java.lang.System.out;


public class act1 {
    public static void main(String[] args) throws FileNotFoundException {
        PrintWriter a = new PrintWriter("hello.txt");
        a.println("Hello, World!");
        a.close();
        Scanner sc = new Scanner(new File("hello.txt"));
        while (sc.hasNextLine()){
            out.println(sc.nextLine());
        }
    }
}
